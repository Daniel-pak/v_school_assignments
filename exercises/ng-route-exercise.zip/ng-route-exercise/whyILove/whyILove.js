angular.module("routingApp")
.controller("LoveController", ["$scope", function($scope){ 
    
    $scope.pictures=["http://www.roadstopguide.com/wp-content/uploads/2015/06/lucy.jpg", "http://cdn.mntm.me/89/3f/bd/landscape-Cape_May-New_Jersey-893fbdb64e66463aaee7ab184491d2ad.jpg", "http://cdn.visitnj.org/sites/default/master/files/styles/profile-slideshow/public/zzdata-5081_640x512.jpg", "https://collabcubed.files.wordpress.com/2012/03/1109-empty-sky_davidsundberg-esto_collabcubed.jpg" ]
    
}])